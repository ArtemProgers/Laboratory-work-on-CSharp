﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Laba_1._2_TP
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            textBox2.Clear();
            textBox3.Clear();
            CultureInfo culture = new CultureInfo("en-US");
            double eps = Convert.ToDouble(textBox1.Text, culture);
            int k = 1;
            double S = 0;
            double S1 = 0;
            double S2 = 0;

            for (double x = 0.5; x < 0.76;)
            {
                while (k > 0)
                {
                    S1 = (2 * Math.Pow(x, 4 * k) * (4 * k + 1 + x)) / (Fact(4 * k + 1));  //ряд k
                    S2 = (2 * Math.Pow(x, 4 * (k + 1)) * (4 * (k + 1) + 1 + x)) / (Fact(4 * (k + 1) + 1)); //ряд k+1
                    S += S1;
                    if (Math.Abs(S2 - S1) > eps) k = -1;
                    //else k += 1;
                }

                double f = Math.Sin(x) - 2 * x - 2 + Math.Cos(x) + Math.Exp(x);//функция
                textBox2.AppendText("X: " + x + " res: " + Convert.ToString(S) + "\r\n");
                textBox3.AppendText("X: " + x + " res: " + Convert.ToString(f) + "\r\n");
                k = 1;
                x += Convert.ToDouble(textBox4.Text, culture);
            }
        }

        public int Fact(int n){
            if (n == 1) return 1;
            return n * Fact(n - 1);
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }
    }
}
