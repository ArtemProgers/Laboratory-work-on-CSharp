﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Laba_2._1_TP
{
    public partial class Form1 : Form
    {
        private readonly double[] array = { 3.5, -2.7, 1.2, 4.8, -0.5, -1.1, 2.3, -3.9, 0.6 };

        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            double min = array.Min();
            int index = Array.IndexOf(array, min);
            textBox2.Text = (index + 1).ToString();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            int firstNegativeIndex = Array.IndexOf(array, array.FirstOrDefault(x => x < 0));
            int secondNegativeIndex = Array.IndexOf(array, array.FirstOrDefault(x => x < 0 && Array.IndexOf(array, x) > firstNegativeIndex));

            if (firstNegativeIndex == -1 || secondNegativeIndex == -1)
            {
                textBox3.Text = "Отрицательные элементы не найдены";
                return;
            }

            double sum = 0;
            for (int i = firstNegativeIndex + 1; i < secondNegativeIndex; i++)
            {
                sum += array[i];
            }
            textBox3.Text = sum.ToString();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            double[] sortedArray = array.OrderBy(x => Math.Abs(x) > 1 ? 1 : 0).ToArray();
            textBox1.Text = string.Join(", ", sortedArray.Select(x => x.ToString()));
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            textBox1.Text = string.Join(", ", array.Select(x => x.ToString()));
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }
    }
}
