﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Runtime.InteropServices;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Laba_4._1_TP
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            List<int> numbers = new List<int>();

            string[] input = textBox1.Text.Split(' ');

            foreach (string num in input)
            {
                if (int.TryParse(num, out int number)) numbers.Add(number);
            }

            int positiveCount = 0;
            foreach (int num in numbers)
            {
                if (num > 0) positiveCount++;
            }

            if (positiveCount <= 5) textBox1.AppendText(Environment.NewLine + "Кол-во полож. чисел НЕ превышает или равно 5" + Environment.NewLine);
            else textBox1.AppendText(Environment.NewLine + "Кол-во полож. чисел превышает 5" + Environment.NewLine);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try {
                string filePath = "C:\\Users\\post1\\OneDrive\\Документы\\Visual Studio 2022\\Laba-4.1-TP\\Laba-4.1-2.exe";

                // Создаем новый процесс для запуска внешнего exe-файла
                Process process = new Process();
                process.StartInfo.FileName = filePath;

                process.Start();

                ////process.WaitForExit();

                //process.Close();

                MessageBox.Show("Программа 4.2 выполнена успешно!");
            }
            catch (Exception ex) {
                MessageBox.Show("Ошибка при запуске внешнего exe-файла: " + ex.Message);
            }
        }

        public static bool CheckSequence(int n, int[] a, int[] b)
        {
            // Шаг 1: Проверяем каждый элемент a[i] на присутствие в b
            foreach (int num in a)
            {
                if (!b.Contains(num)) return false; 
            }

            // Шаг 2: Проверяем, что a[i] встречается в b не позднее, чем a[i+1]
            for (int i = 0; i < a.Length - 1; i++)
            {
                int aIndexInB = Array.IndexOf(b, a[i]);
                int nextAIndexInB = Array.IndexOf(b, a[i + 1]);

                if (nextAIndexInB < aIndexInB) return false;
            }

            // Шаг 3: Верное условие выполнено
            return true;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            string firstLine = textBox2.Lines[0];
            string secondLine = textBox2.Lines[1];

            int[] a = Array.ConvertAll(textBox2.Lines[0].Split(' '), int.Parse);
            int[] b = Array.ConvertAll(textBox2.Lines[1].Split(' '), int.Parse);

            //int[] a = new int[] { 1, 2, 3, 4, 5 };
            //int[] b = new int[] { 6, 7, 8, 9, 10, 1, 2, 3, 4, 5 };

            bool result = CheckSequence(a.Length, a, b);
            textBox2.AppendText(Environment.NewLine + "Результат " + result + Environment.NewLine);
        }
    }
}
