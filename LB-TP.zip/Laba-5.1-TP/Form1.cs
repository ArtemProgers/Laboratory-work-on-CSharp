﻿using System;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using System.IO;

namespace Laba_5._1_TP
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string filePath = "C:\\Users\\post1\\OneDrive\\Документы\\Visual Studio 2022\\Laba-5.1-TP\\file-Laba-5.txt";

            // Читаем содержимое файла
            string fileContent = File.ReadAllText(filePath);

            int plusCount = 0, minusCount = 0, asteriskCount = 0;
            foreach (char c in fileContent)
            {
                if (c == '+') plusCount++;
                else if (c == '-') minusCount++;
                else if (c == '*') asteriskCount++;
            }

            textBox1.AppendText("+ = " + plusCount + Environment.NewLine);
            textBox1.AppendText("- = " + minusCount + Environment.NewLine);
            textBox1.AppendText("* = " + asteriskCount + Environment.NewLine);
        }

        private void button2_Click(object sender, EventArgs e) {
            string surnamesFilePath = "names.txt";
            StreamWriter surnamesFile = new StreamWriter(surnamesFilePath);

            surnamesFile.WriteLine("Иванов");
            surnamesFile.WriteLine("Петров");
            surnamesFile.WriteLine("Сидоров");
            surnamesFile.WriteLine("Смирнов");
            surnamesFile.WriteLine("Кузнецов");

            surnamesFile.Close();

            string phonesFilePath = "phones.txt";
            StreamWriter phonesFile = new StreamWriter(phonesFilePath);

            phonesFile.WriteLine("+7111111111");
            phonesFile.WriteLine("+722222222");
            phonesFile.WriteLine("+733333333");
            phonesFile.WriteLine("+744444444");
            phonesFile.WriteLine("+755555555");

            phonesFile.Close();

            string surname = textBox2.Lines[0];

            StreamReader surnamesReader = new StreamReader(surnamesFilePath);
            StreamReader phonesReader = new StreamReader(phonesFilePath);

            string line;
            string phone = "";

            // Считываем фамилии в файле построчно
            while ((line = surnamesReader.ReadLine()) != null)
            {
                if (line == surname)
                {
                    phone = phonesReader.ReadLine();
                    break;
                }
                else phonesReader.ReadLine();
            }
            surnamesReader.Close();
            phonesReader.Close();

            if (phone != "") textBox2.AppendText(Environment.NewLine + "Номер телефона " + surname + ": " + phone);
            else textBox2.AppendText(Environment.NewLine + "Такой фамилии нет ");
        }
    }
}
