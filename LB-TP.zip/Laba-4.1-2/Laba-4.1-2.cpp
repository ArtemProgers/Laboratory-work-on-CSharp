﻿#include <iostream>
#include <vector>
#include <limits.h>
#include <locale>

using namespace std;

vector<int> P, W;
int n;
int E, F;
vector<int> MAX, MIN;

void input()
{
    cout << "Введите E и F" << endl;
    cin >> E >> F;
    cout << "Введите N" << endl;
    cin >> n;
    MAX = vector<int>(F - E + 1, INT_MIN);
    MIN = vector<int>(F - E + 1, INT_MAX);
    P.resize(n); W.resize(n);
    cout << "Введите P и W" << endl;
    for (int i = 0; i < n; i++)
        cin >> P[i] >> W[i];
}
void solve()
{
    MIN[0] = 0;
    MAX[0] = 0;
    for (int i = 0; i < MIN.size(); i++)
    {
        for (int j = 0; j < W.size(); j++)
        {
            if (i - W[j] >= 0 && MIN[i - W[j]] != INT_MAX)
            {
                MIN[i] = min(MIN[i], MIN[i - W[j]] + P[j]);
                MAX[i] = max(MAX[i], MAX[i - W[j]] + P[j]);
            }
        }
    }

}
void output()
{
    if (MIN.back() == INT_MAX)
        cout << " Это невозможно!";
    else
        cout << " Минимальная сумма: " << MIN.back() << '\n' << "Максимальная сумма: " << MAX.back();
}
int main()
{
    setlocale(LC_ALL, "Russian");
    input();
    solve();
    output();

    return 0;
}