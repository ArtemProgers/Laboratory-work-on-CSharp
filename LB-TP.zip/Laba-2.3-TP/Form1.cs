﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Laba_2._3_TP
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // Добавляем столбцы для максимального количества ячеек
            for (int i = 0; i < 6; i++)
            {
                DataGridViewTextBoxColumn column = new DataGridViewTextBoxColumn();
                column.HeaderText = " ";
                dataGridView1.Columns.Add(column);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Random random = new Random();
            dataGridView1.Rows.Clear();

            int[] cellCounts = { 1, 2, 5, 6, 2, 1 };

            for (int i = 0; i < cellCounts.Length; i++)
            {
                DataGridViewRow row = new DataGridViewRow();

                for (int j = 0; j < cellCounts[i]; j++)
                {
                    int randomNumber = random.Next(1, 500);
                    row.Cells.Add(new DataGridViewTextBoxCell { Value = randomNumber });
                }
                dataGridView1.Rows.Add(row);
            }
        }
    }
}
