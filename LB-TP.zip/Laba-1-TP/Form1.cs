﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Laba_1_TP
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            double x = Convert.ToDouble(textBox1.Text);
            double y = Convert.ToDouble(textBox2.Text);
            textBox3.Text = Convert.ToString(Math.Pow(Math.Cos(x), 4) + Math.Pow(Math.Sin(y), 2) + 1 / 4 * Math.Pow(Math.Sin(x), 2) - 1);
            textBox4.Text = Convert.ToString(Math.Sin(y + x) * Math.Sin(y - x));
        }
    }
}
