﻿using System;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.Tab;

namespace Laba_6_TP
{
    public partial class Form1 : Form
    {
        public Date currentDate;

        public Form1()
        {
            InitializeComponent();
            DateTime today = DateTime.Today;
            currentDate = new Date(today.Day, today.Month, today.Year);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(textBox3.Text) && string.IsNullOrEmpty(textBox4.Text) && string.IsNullOrEmpty(textBox5.Text))
                textBox1.Text = currentDate.ToString();
            else
            {
                if (int.TryParse(textBox3.Text, out int day) && int.TryParse(textBox4.Text, out int month) && int.TryParse(textBox5.Text, out int year))
                {
                    currentDate = new Date(day, month, year);
                    textBox1.Text = currentDate.ToString();
                }
                else MessageBox.Show("Введите корректные числовые значения для дня, месяца и года. Или заполните все поля");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            int.TryParse(textBox3.Text, out int day);
            int.TryParse(textBox4.Text, out int month);
            int.TryParse(textBox5.Text, out int year);
            DateWithDayOfWeek date = new DateWithDayOfWeek(day, month, year);
            textBox2.Text = date.GetDayOfWeek().ToString();
        }
    }

    public class Date //класс
    {
        public int day = 1; // Дата
        public int month = 1;
        public int year = 2000;

        public Date(int day, int month, int year) // Конструктор
        {
            SetDate(day, month, year);
        }

        public void SetDate(int day, int month, int year) // Обработка ошибки ввода
        {
            if (!IsValidDate(day, month, year)) throw new ArgumentException("Ошибка даты");

            this.day = day;
            this.month = month;
            this.year = year;
        }

        private bool IsValidDate(int day, int month, int year) // Проверка
        {
            if (year < 1 || month < 1 || month > 12 || day < 1 || day > DateTime.DaysInMonth(year, month))
                return false;
            return true;
        }

        public int Day // Инкапсуляция
        {
            get { return day; }
            set
            {
                if (IsValidDate(value, month, year)) day = value;
                else throw new ArgumentException("Ошибка дня");
            }
        }

        public int Month
        {
            get { return month; }
            set
            {
                if (IsValidDate(value, month, year)) month = value;
                else throw new ArgumentException("Ошибка месяца");
            }
        }

        public int Year
        {
            get { return year; }
            set
            {
                if (IsValidDate(day, month, value)) year = value;
                else throw new ArgumentException("Ошибка года");
            }
        }
        public override string ToString() // Вывод
        {
            return $" {day:D2}/{month:D2}/{year:D4} ";
        }
    }

    public class DateWithDayOfWeek : Date // Дочерний класс
    {
        public DateWithDayOfWeek(int day, int month, int year) : base(day, month, year)
        {
        }

        public DayOfWeek GetDayOfWeek() // Метод для определения дня недели
        {
            return new DateTime(year, month, day).DayOfWeek;
        }
    }
}
