﻿using System;
using System.Windows.Forms;

namespace Laba_7._3_TP
{
    public partial class Form1 : Form
    {
        //IOrganization currentOrganization;
        Factory[] factories = new Factory[10];
        InsuranceCompany[] insuranceCompanies = new InsuranceCompany[10];

        // Делегат
        public delegate void OrganizationInfoHandler(string info);

        // Событие 
        public event OrganizationInfoHandler OrganizationInfoEvent;

        public Form1()
        {
            InitializeComponent();

            comboBox1.Items.Add("Завод");
            comboBox1.Items.Add("Страховая компания");
            comboBox2.Items.Add("Завод");
            comboBox2.Items.Add("Страховая компания");

            OrganizationInfoEvent += UpdateOrganizationInfo;
        }

        private void UpdateOrganizationInfo(string info) //обработчик
        {
            textBox3.Text = info;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string name = textBox1.Text;
            string type = comboBox1.SelectedItem.ToString();
            string additionalInfo = $"{textBox4.Text}, {textBox5.Text}";
            string directorFullName = textBox7.Text;
            string accountNumber = textBox8.Text;
            decimal annualIncome = decimal.Parse(textBox9.Text);
            string legalAddress = textBox10.Text;

            if (type == "Завод")
            {
                for (int i = 0; i < factories.Length; i++)
                {
                    if (factories[i] == null)
                    {
                        factories[i] = new Factory
                        {
                            Name = name,
                            AdditionalInfo = additionalInfo,
                            DirectorFullName = directorFullName,
                            AccountNumber = accountNumber,
                            AnnualIncome = annualIncome,
                            LegalAddress = legalAddress
                        };
                        break;
                    }
                }
            }
            else if (type == "Страховая компания")
            {
                for (int i = 0; i < insuranceCompanies.Length; i++)
                {
                    if (insuranceCompanies[i] == null)
                    {
                        insuranceCompanies[i] = new InsuranceCompany
                        {
                            Name = name,
                            AdditionalInfo = additionalInfo,
                            DirectorFullName = directorFullName,
                            AccountNumber = accountNumber,
                            AnnualIncome = annualIncome,
                            LegalAddress = legalAddress
                        };
                        break;
                    }
                }
            }

            textBox3.Text = "Организация успешно создана!";
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string name = textBox2.Text;
            string type = comboBox2.SelectedItem.ToString();

            string info = "";

            if (type == "Завод")
            {
                foreach (var factory in factories)
                {
                    if (factory != null && factory.Name == name)
                    {
                        info = factory.GetInfo();
                        break;
                    }
                }
            }
            else if (type == "Страховая компания")
            {
                foreach (var insuranceCompany in insuranceCompanies)
                {
                    if (insuranceCompany != null && insuranceCompany.Name == name)
                    {
                        info = insuranceCompany.GetInfo();
                        break;
                    }
                }
            }
            OrganizationInfoEvent?.Invoke(info);
            //string name = textBox2.Text;
            //string type = comboBox2.SelectedItem.ToString();

            //string info = "";

            //if (type == "Завод")
            //{
            //    foreach (var factory in factories)
            //    {
            //        if (factory != null && factory.Name == name)
            //        {
            //            info = factory.GetInfo();
            //            break;
            //        }
            //    }
            //}
            //else if (type == "Страховая компания")
            //{
            //    foreach (var insuranceCompany in insuranceCompanies)
            //    {
            //        if (insuranceCompany != null && insuranceCompany.Name == name)
            //        {
            //            info = insuranceCompany.GetInfo();
            //            break;
            //        }
            //    }
            //}

            //if (info == "") info = "Организация не найдена";
            //textBox3.Text = info;
        }

        private void label11_Click(object sender, EventArgs e)
        {

        }
    }
    // Интерфейс организации
    interface IOrganization
    {
        string Name { get; set; }
        string Type { get; set; }
        string AdditionalInfo { get; set; }
        string GetInfo();
    }

    // Класс для завода
    class Factory : IOrganization
    {
        public string Name { get; set; }
        public string Type { get; set; } = "Завод";
        public string IIN { get; set; }
        public string SphereOfActivity { get; set; }
        public string DirectorFullName { get; set; }
        public string AccountNumber { get; set; }
        public decimal AnnualIncome { get; set; }
        public string LegalAddress { get; set; }

        public string AdditionalInfo
        {
            get
            {
                return $"ИИН: {IIN}, Сфера деятельности: {SphereOfActivity}";
            }
            set
            {
                string[] data = value.Split(',');
                if (data.Length == 2)
                {
                    IIN = data[0].Trim();
                    SphereOfActivity = data[1].Trim();
                }
            }
        }

        public string GetInfo()
        {
            return $"Название: {Name}, Тип: {Type}, {AdditionalInfo}, " +
               $"Руководитель: {DirectorFullName}, Расчетный счет: {AccountNumber}, " +
               $"Годовой доход: {AnnualIncome}, Юридический адрес: {LegalAddress}";
        }
    }

    // Класс для страховой компании
    class InsuranceCompany : IOrganization
    {
        public string Name { get; set; }
        public string Type { get; set; } = "Страховая компания";
        public string LicenseNumber { get; set; }
        public string Region { get; set; }
        public string DirectorFullName { get; set; }
        public string AccountNumber { get; set; }
        public decimal AnnualIncome { get; set; }
        public string LegalAddress { get; set; }

        public string AdditionalInfo
        {
            get
            {
                return $"Номер лицензии: {LicenseNumber}, Регион: {Region}";
            }
            set
            {
                string[] data = value.Split(',');
                if (data.Length == 2)
                {
                    LicenseNumber = data[0].Trim();
                    Region = data[1].Trim();
                }
            }
        }

        public string GetInfo()
        {
            return $"Название: {Name}, Тип: {Type}, {AdditionalInfo}, " +
               $"Руководитель: {DirectorFullName}, Расчетный счет: {AccountNumber}, " +
               $"Годовой доход: {AnnualIncome}, Юридический адрес: {LegalAddress}";
        }
    }
}