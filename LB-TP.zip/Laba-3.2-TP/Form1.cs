﻿using System;
using System.IO;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows.Forms;

namespace Laba_3._2_TP
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog1 = new OpenFileDialog();

            openFileDialog1.Filter = "Текстовые файлы (*.txt)|*.txt";

            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                try
                {
                    string filePath = openFileDialog1.FileName;
                    string fileContent = File.ReadAllText(filePath, Encoding.UTF8);

                    textBox1.Text = fileContent;

                    count(fileContent);
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Ошибка чтения файла: " + ex.Message);
                }
            }
        }
        public void count(string fileContent)
        {
            string text = fileContent;
            Regex countLetterRegex = new Regex(@"[A-zА-яЁё]");
            MatchCollection countLetterMatch = countLetterRegex.Matches(text);
            int letter = countLetterMatch.Count;
            Regex countNumberRegex = new Regex(@"[^\D\s]");
            MatchCollection countNumberMatch = countNumberRegex.Matches(text);
            int number = countNumberMatch.Count;
            if (letter > number)
            {
                textBox1.AppendText(Environment.NewLine + "Количество букв в тексте больше чем цифр" + Environment.NewLine);
                textBox1.AppendText("Количество букв:" + letter + Environment.NewLine);
                textBox1.AppendText("Количество цифр:" + number + Environment.NewLine);
            }
            if (letter < number)
            {
                textBox1.AppendText(Environment.NewLine + "Количество цифр в тексте больше чем букв" + Environment.NewLine);
                textBox1.AppendText("Количество букв:" + letter + Environment.NewLine);
                textBox1.AppendText("Количество цифр:" + number + Environment.NewLine);
            }
        }
    }
}