﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Laba_2._2_TP
{
    public partial class Form1 : Form
    {
        private int[,] matrix = {
            { 1, -2, 3, 4, -5 },
            { -6, 7, -8, 9, 10 },
            { 11, 12, 13, 14, 15 },
            { -16, 17, -18, 19, 20 }
        };

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            DisplayMatrix(matrix);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            SortColumnsByCharacteristics();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            CalculateSumOfColumnsWithNegatives();
        }

        private void DisplayMatrix(int[,] matrix)
        {
            dataGridView1.Rows.Clear();
            dataGridView1.Columns.Clear();

            for (int j = 0; j < matrix.GetLength(1); j++)
            {
                dataGridView1.Columns.Add($"Column{j + 1}", $"Column{j + 1}");
            }

            for (int i = 0; i < matrix.GetLength(0); i++)
            {
                DataGridViewRow row = new DataGridViewRow();
                for (int j = 0; j < matrix.GetLength(1); j++)
                {
                    row.Cells.Add(new DataGridViewTextBoxCell { Value = matrix[i, j] });
                }
                dataGridView1.Rows.Add(row);
            }
        }

        private void SortColumnsByCharacteristics()
        {
            int[] columnCharacteristics = new int[matrix.GetLength(1)];

            for (int j = 0; j < matrix.GetLength(1); j++)
            {
                int sum = 0;
                for (int i = 0; i < matrix.GetLength(0); i++)
                {
                    if (matrix[i, j] < 0 && matrix[i, j] % 2 != 0)
                    {
                        sum += Math.Abs(matrix[i, j]);
                    }
                }
                columnCharacteristics[j] = sum;
            }

            int[] sortedIndices = Enumerable.Range(0, columnCharacteristics.Length).OrderBy(i => columnCharacteristics[i]).ToArray();

            int[,] sortedMatrix = new int[matrix.GetLength(0), matrix.GetLength(1)];

            for (int j = 0; j < matrix.GetLength(1); j++)
            {
                for (int i = 0; i < matrix.GetLength(0); i++)
                {
                    sortedMatrix[i, j] = matrix[i, sortedIndices[j]];
                }
            }

            DisplayMatrix(sortedMatrix);
        }

        private void CalculateSumOfColumnsWithNegatives()
        {
            textBox1.Clear();

            for (int j = 0; j < matrix.GetLength(1); j++)
            {
                int sum = 0;
                bool hasNegative = false;
                for (int i = 0; i < matrix.GetLength(0); i++)
                {
                    if (matrix[i, j] < 0)
                    {
                        hasNegative = true;
                        sum += matrix[i, j];
                    }
                }
                if (hasNegative)
                {
                    textBox1.AppendText($"Column{j + 1}: {sum}\r\n");
                }
            }
        }
    }
}
