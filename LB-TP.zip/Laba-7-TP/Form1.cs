﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Laba_7_TP
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();

            comboBox1.Items.Add("Factory");
            comboBox1.Items.Add("Insurance Company");

            comboBox1.SelectedIndex = 0;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            // Создание объектов классов в соответствии с введенными данными
            IOrganization organization;
            if (comboBox1.Text == "Factory")
            {
                organization = new Factory(textBox2.Text);
            }
            else if (comboBox1.Text == "Insurance Company")
            {
                organization = new InsuranceCompany(textBox2.Text);
            }
            else
            {
                MessageBox.Show("Please select organization type.");
                return;
            }

            // Отображение информации о созданной организации
            organization.DisplayInfo();

            // Если это страховая компания, предоставляем страховые услуги
            if (organization is IInsuranceCompany)
            {
                ((IInsuranceCompany)organization).ProvideInsurance();
            }
        }
    }

    // Пример интерфейса "Организация"
    public interface IOrganization
    {
        void DisplayInfo();
    }

    // Пример интерфейса "Страховая компания"
    public interface IInsuranceCompany
    {
        void ProvideInsurance();
    }

    // Класс "Завод"
    public class Factory : IOrganization
    {
        public string Name { get; set; }

        public Factory(string name)
        {
            Name = name;
        }

        public void DisplayInfo()
        {
            MessageBox.Show($"Factory: {Name}");
        }
    }

    // Класс "Страховая компания"
    public class InsuranceCompany : IOrganization, IInsuranceCompany
    {
        public string Name { get; set; }

        public InsuranceCompany(string name)
        {
            Name = name;
        }

        public void DisplayInfo()
        {
            MessageBox.Show($"Insurance Company: {Name}");
        }

        public void ProvideInsurance()
        {
            MessageBox.Show($"Providing insurance services for {Name}");
        }
    }


}
