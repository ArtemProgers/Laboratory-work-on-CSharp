﻿using System;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.TaskbarClock;

namespace Laba_6_TP_Denis
{
    public partial class Form1 : Form
    {
        public Time currentTime;

        public Form1()
        {
            InitializeComponent();
            DateTime now = DateTime.Now; //системный класс
            currentTime = new Time(now.Hour, now.Minute, now.Second); //получение реального времени
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(textBox2.Text) && string.IsNullOrEmpty(textBox3.Text) && string.IsNullOrEmpty(textBox4.Text))
                textBox1.Text = currentTime.ToString();
            else
            {
                if (int.TryParse(textBox2.Text, out int hour) && int.TryParse(textBox3.Text, out int minute) && int.TryParse(textBox4.Text, out int second))
                {
                    currentTime = new Time(hour, minute, second);
                    textBox1.Text = currentTime.ToString();
                }
                else MessageBox.Show("Введите корректные числовые значения для часа, минуты и секунды. Или заполните все поля");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (int.TryParse(textBox5.Text, out int hours) && int.TryParse(textBox6.Text, out int minutes) && int.TryParse(textBox7.Text, out int seconds))
            {
                currentTime.AddToTime(hours, minutes, seconds); // Обновляем текущее время
                textBox1.Text = currentTime.ToString(); // Обновляем содержимое textBox1 с помощью нового времени
            }
            else
            {
                MessageBox.Show("Введите корректные числовые значения для часа, минуты и секунды.");
            }
        }
    }

    public class Time // класс
    {
        public int hour = 0; // Время
        public int minute = 0;
        public int second = 0;

        public Time(int hour, int minute, int second) // Конструктор
        {
            SetTime(hour, minute, second);
        }

        public void SetTime(int hour, int minute, int second) // Обработка ошибки ввода
        {
            if (!IsValidTime(hour, minute, second)) throw new ArgumentException("Ошибка в установки времени");

            this.hour = hour;
            this.minute = minute;
            this.second = second;
        }

        public void AddToTime(int hour, int minute, int second)
        {
            // Добавляем переданные значения к текущему времени
            this.hour = (this.hour + hour) % 24;
            this.minute = (this.minute + minute + (this.second + second) / 60) % 60;
            this.second = (this.second + second) % 60;
        }

        private bool IsValidTime(int hour, int minute, int second) // Проверка
        {
            if (hour < 0 || hour > 23 || minute < 0 || minute > 59 || second < 0 || second > 59)
                return false;
            return true;
        }

        public override string ToString() // Вывод
        {
            return $" {hour:D2}:{minute:D2}:{second:D2} ";
        }
    }

    //public class AddTime : Time
    //{
    //    public AddTime(int hour, int minute, int second) : base(0, 0, 0)
    //    {
    //        AddToTime(hour, minute, second);
    //    }

    //    public void AddToTime(int hour, int minute, int second)
    //    {
    //        // Добавляем переданные значения к текущему времени
    //        this.hour = (this.hour + hour);
    //        this.minute = (this.minute + minute + (this.second + second) / 60);
    //        this.second = (this.second + second);
    //    }
    //}
}
