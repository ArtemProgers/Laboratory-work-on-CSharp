﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Laba_3._1_TP
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string inputText = textBox1.Text;
            string[] words = inputText.Split(' ');

            List<string> quotedWords = new List<string>();

            int startIndex = 0;
            int endIndex = 0;
            const string end = "\".";

            while (startIndex < inputText.Length)
            {
                startIndex = inputText.IndexOf("\"", endIndex);

                if (startIndex == -1) break; 
                
                endIndex = inputText.IndexOf(end, startIndex + 1); 

                if (endIndex == -1) break; 
                
                string sentence = inputText.Substring(startIndex + 1, endIndex - startIndex - 1); 

                quotedWords.Add(sentence.Trim('\"')); 
            }

            textBox2.Text = string.Join(", ", quotedWords);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string inputText = textBox1.Text;
            string[] words = inputText.Split(' ');

            words = words.Select(x => x.Replace("\"", "")).ToArray();

            Dictionary<string, int> wordCount = new Dictionary<string, int>();

            foreach (string word in words)
            {
                if (wordCount.ContainsKey(word)) wordCount[word]++;
                else wordCount[word] = 1;
            }

            List<string> uniqueWords = new List<string>();

            foreach (KeyValuePair<string, int> pair in wordCount)
            {
                if (pair.Value == 1) uniqueWords.Add(pair.Key);
            }
            textBox2.Text = string.Join(", ", uniqueWords);
        }
    }
}
